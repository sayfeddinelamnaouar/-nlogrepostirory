<?php
    // Functie: classdefinitie User 
    // Auteur: Wigmans

    class User{

        // Eigenschappen 
        public $username;
        public $email;
        private $password;
        
        public function ShowUser() {
            echo "<br>Username: $this->username<br>";
            echo "<br>Password: $this->password<br>";
            echo "<br>Email: $this->email<br>";
        }

        public function RegisterUser(){
            
        }

        function SetPassword($password){
            $this->password = $password;
        }
        function GetPassword(){
            return $this->password;
        }

        function ValidateUser(){
            $errors=[];

            if (empty($this->username)){
                array_push($errors, "Invalid username");
            } else if (empty($this->password)){
                array_push($errors, "Invalid password");
            }
            
            return $errors;
        }

        public function LoginUser(){
            $errors = [];

            // Maak verbinding met de database
            $dsn = 'mysql:host=localhost;dbname=database';
            $pass = 'password';
            $pdo = new PDO($dsn, $user, $pass);
            
            // Controleer of de verbinding is gelukt
            if (!$pdo) {
                array_push($errors, "Kan geen verbinding maken met de database: " . $pdo->errorInfo());
                return false;
            }

            // Zoek de gebruiker op basis van de gebruikersnaam en het wachtwoord
            $sql = "SELECT * FROM users WHERE username=:username AND password=:password";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':username', $this->username);
            $stmt->bindParam(':password', $this->password);
            $stmt->execute();

            // Controleer of er een rij is gevonden
            if ($stmt->rowCount() == 1) {
                // Haal de gebruikersgegevens op
                $row = $stmt->fetch();

                // Sla de gebruikersgegevens op in de sessie
                session_start();
                $_SESSION["user_id"] = $row["id"];
                $_SESSION["user_name"] = $row["username"];
                $_SESSION["user_email"] = $row["email"];

                // Sluit de databaseverbinding en geef aan dat het inloggen is gelukt
                $pdo = null;
                return true;
            } else {
                // Geef aan dat het inloggen is mislukt
                array_push($errors, "Ongeldige gebruikersnaam of wachtwoord");
                $pdo = null;
                return false;
            }
        }
    }
?>
